/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Plus, 
  Trash2, 
  HelpCircle, 
  ChevronRight, 
  Mail, 
  Lock, 
  CheckCircle, 
  FileText, 
  Activity, 
  Printer, 
  RefreshCw, 
  ArrowLeft, 
  Sparkles, 
  DollarSign, 
  AlertTriangle,
  Send,
  Eye,
  Hospital
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ManualProcedure, 
  AnalyzedProcedure, 
  OverallAnalysis, 
  CompilationResult, 
  AppState 
} from './types';

// Predefined dental treatment plan samples for instant evaluation
const SAMPLES = [
  {
    title: "Restorative Crown & Core Buildup",
    type: "manual" as const,
    items: [
      { name: "D2740 Crown - Porcelain/Ceramic substrate", cost: "1420" },
      { name: "D2950 Core buildup, including any pins", cost: "310" },
      { name: "D0220 Intraoral periapical primary image", cost: "45" }
    ]
  },
  {
    title: "Periodontal Scaling (Deep Cleaning)",
    type: "manual" as const,
    items: [
      { name: "D4341 Periodontal scaling/root planing - 4+ teeth per quad (UR)", cost: "330" },
      { name: "D4341 Periodontal scaling/root planing - 4+ teeth per quad (LR)", cost: "330" },
      { name: "D0150 Comprehensive Oral Evaluation - New Patient", cost: "125" },
      { name: "D0210 Intraoral complete series radiograph film", cost: "180" }
    ]
  },
  {
    title: "Pasted Diagnostic Invoice (Raw Text)",
    type: "pasted" as const,
    text: `PROPOSAL FOR DENTAL SERVICE
Dr. Smith Family Dental Healthcare
Patient: John Doe | Date: May 2026

Tooth #18: D2393 Resin composite - three surfaces posterior  - Price: $290
Tooth #19: D2750 Crown - porcelain fused to high noble metal - Price: $1,480
Tooth #19: D2950 Core buildup under crown - Price: $350
Diagnostic: D0120 Periodic oral examination - Price: $85
D1110 Prophylaxis - adult - Price: $110
TOTAL ESTIMATED PATIENT BALANCE: $2,315`
  }
];

export default function App() {
  // App routing steps: home -> input -> email-capture -> results -> pricing
  const [step, setStep] = useState<AppState>('home');
  const [inputType, setInputType] = useState<'manual' | 'pasted'>('manual');
  
  // Pro Tier Subscription states
  const [isPro, setIsPro] = useState<boolean>(() => {
    return localStorage.getItem('clearplan_is_pro') === 'true';
  });
  const [freeAnalysesCount, setFreeAnalysesCount] = useState<number>(() => {
    const saved = localStorage.getItem('clearplan_free_count');
    return saved ? parseInt(saved, 10) : 0;
  });
  const [savedAnalyses, setSavedAnalyses] = useState<any[]>(() => {
    const saved = localStorage.getItem('clearplan_saved_analyses');
    try {
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Simulated Checkout Dialog
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [checkoutCardName, setCheckoutCardName] = useState('');
  const [checkoutCardNum, setCheckoutCardNum] = useState('');
  const [checkoutZip, setCheckoutZip] = useState('');
  const [checkoutProcessing, setCheckoutProcessing] = useState(false);
  
  // Input fields
  const [manualProcedures, setManualProcedures] = useState<ManualProcedure[]>([
    { name: '', cost: '' }
  ]);
  const [rawText, setRawText] = useState('');
  const [email, setEmail] = useState('');
  const [agreedToTerms, setAgreedToTerms] = useState(true);

  // AI results
  const [result, setResult] = useState<CompilationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Lead tracking list (loaded secretly from backend)
  const [leads, setLeads] = useState<any[]>([]);
  const [showAdminTab, setShowAdminTab] = useState(false);

  // Setup sample dental plan
  const loadSample = (sampleIndex: number) => {
    const selected = SAMPLES[sampleIndex];
    if (selected.type === 'manual') {
      setInputType('manual');
      setManualProcedures(selected.items.map(item => ({ name: item.name, cost: item.cost })));
    } else {
      setInputType('pasted');
      setRawText(selected.text || '');
    }
  };

  // Add a new row to manual procedures entry table
  const addProcedureRow = () => {
    setManualProcedures([...manualProcedures, { name: '', cost: '' }]);
  };

  // Remove a row from manual procedures entry table
  const removeProcedureRow = (index: number) => {
    if (manualProcedures.length === 1) {
      setManualProcedures([{ name: '', cost: '' }]);
    } else {
      setManualProcedures(manualProcedures.filter((_, idx) => idx !== index));
    }
  };

  // Update a single field inside manual entry rows
  const handleManualProcedureChange = (index: number, field: keyof ManualProcedure, value: string) => {
    const updated = [...manualProcedures];
    updated[index][field] = value;
    setManualProcedures(updated);
  };

  // Calculate sum of manual procedures
  const getManualTotal = () => {
    return manualProcedures.reduce((acc, item) => acc + (parseFloat(item.cost) || 0), 0);
  };

  // Verify inputs and navigate to email capture
  const handleProceedToEmail = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Validation
    if (inputType === 'manual') {
      const validRows = manualProcedures.filter(p => p.name.trim() !== '');
      if (validRows.length === 0) {
        setError("Please enter at least one procedure name/code.");
        return;
      }
    } else {
      if (!rawText.trim()) {
        setError("Please paste the treatment description text from your printout.");
        return;
      }
    }

    if (!isPro && freeAnalysesCount >= 1) {
      setError("You have reached the Free Plan limit of 1 analysis. Upgrade to ClearPlan Pro for unlimited analyses!");
      setStep('pricing');
      return;
    }

    setStep('email-capture');
  };

  // Fire server-side Gemini analysis
  const handleAnalyzePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) {
      setError("Please specify a valid email address.");
      return;
    }
    if (!agreedToTerms) {
      setError("Please check the disclaimer confirmation to continue.");
      return;
    }

    if (!isPro && freeAnalysesCount >= 1) {
      setError("You have reached the Free Plan limit of 1 analysis. Upgrade to ClearPlan Pro for unlimited analyses!");
      setStep('pricing');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const payload = {
        email: email.trim(),
        rawText: inputType === 'pasted' ? rawText : '',
        manualProcedures: inputType === 'manual' ? manualProcedures.filter(p => p.name.trim() !== '') : []
      };

      const res = await fetch('/api/analyze-treatment-plan', {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const errBody = await res.json();
        throw new Error(errBody.error || "The analysis server encountered an issue processing the treatment plan.");
      }

      const parsedResult: CompilationResult = await res.json();
      setResult(parsedResult);

      // Calculate estimated cost
      let estCost = 0;
      if (payload.manualProcedures && payload.manualProcedures.length > 0) {
        estCost = payload.manualProcedures.reduce((acc: number, p: any) => acc + (parseFloat(p.cost) || 0), 0);
      } else if (payload.rawText) {
        const dollarMatches = payload.rawText.match(/\$?([0-9]{3,5})/g);
        if (dollarMatches) {
          estCost = dollarMatches.reduce((acc: number, str: string) => acc + (parseFloat(str.replace(/[^0-9.]/g, '')) || 0), 0);
        }
      }

      // Check tier limit or save history
      if (!isPro) {
        const newCount = freeAnalysesCount + 1;
        setFreeAnalysesCount(newCount);
        localStorage.setItem('clearplan_free_count', String(newCount));
      } else {
        const newRecord = {
          id: 'analysis_' + Math.random().toString(36).substring(2, 9),
          timestamp: new Date().toISOString(),
          email: email.trim(),
          estCost: estCost,
          result: parsedResult
        };
        const updated = [newRecord, ...savedAnalyses];
        setSavedAnalyses(updated);
        localStorage.setItem('clearplan_saved_analyses', JSON.stringify(updated));
      }

      setStep('results');
      
      // Fetch latest leads from backend securely for administration logs
      fetchLeads();
    } catch (err: any) {
      console.error(err);
      setError(err?.message || "Something went wrong during plan analysis. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Delete from local history
  const deleteSavedAnalysis = (idToDelete: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = savedAnalyses.filter(item => item.id !== idToDelete);
    setSavedAnalyses(updated);
    localStorage.setItem('clearplan_saved_analyses', JSON.stringify(updated));
  };

  // Load from local history
  const loadSavedAnalysis = (saved: any) => {
    setEmail(saved.email);
    setResult(saved.result);
    setStep('results');
  };

  // Clear tracking list and start over
  const resetApp = () => {
    setStep('home');
    setManualProcedures([{ name: '', cost: '' }]);
    setRawText('');
    setResult(null);
    setError(null);
  };

  // Fetch Captured submissions leads for administrative auditing
  const fetchLeads = async () => {
    try {
      const res = await fetch('/api/dashboard-leads');
      if (res.ok) {
        const data = await res.json();
        setLeads(data.leads || []);
      }
    } catch (e) {
      console.error("Could not fetch captured leads dashboard", e);
    }
  };

  useEffect(() => {
    fetchLeads();
  }, []);

  // Check if visitor email is dentist/admin to automatically display lead inquiries dashboard
  useEffect(() => {
    if (email.trim().toLowerCase() === 'swearingendds@gmail.com') {
      setShowAdminTab(true);
    }
  }, [email]);

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 flex flex-col justify-between selection:bg-sky-100 print:bg-white print:text-black">
      
      {/* HEADER / NAV AREA */}
      <header className="bg-white border-b border-slate-200 py-4 px-6 text-slate-800 sticky top-0 z-50 shadow-xs print:bg-white print:text-slate-900 print:shadow-none print:border-b-2 print:border-slate-300">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2.5 cursor-pointer" id="logo_btn" onClick={resetApp}>
            <div className="bg-brand text-white p-2 rounded-lg flex items-center justify-center font-display shadow-xs print:bg-slate-900">
              <ShieldCheck className="h-5.5 w-5.5 stroke-[2.5]" />
            </div>
            <div>
              <span className="font-display text-xl font-bold tracking-tight text-brand">Clear<span className="text-sky-600 font-semibold">Plan</span></span>
              <p className="text-[9px] text-slate-500 -mt-0.5 tracking-widest uppercase font-mono print:hidden">Dental Advocate Platform</p>
            </div>
          </div>
          
          <nav className="flex items-center gap-6 print:hidden">
            {isPro && (
              <span className="bg-gradient-to-r from-amber-500 to-yellow-500 text-white font-bold tracking-wider uppercase text-[10px] px-2.5 py-1 rounded-full shadow-xs">
                ★ Pro Member
              </span>
            )}

            {leads.length > 0 && (
              <button 
                onClick={() => setShowAdminTab(!showAdminTab)}
                id="admin_button"
                className="text-xs py-1.5 px-3 rounded-full flex items-center gap-1.5 font-bold transition-all bg-sky-50 text-brand border border-sky-100 hover:bg-sky-100"
              >
                <Hospital className="h-3.5 w-3.5 text-sky-600 animate-pulse" />
                <span>My Analyses ({leads.length})</span>
              </button>
            )}
            
            <button 
              onClick={resetApp}
              id="top_nav_home"
              className={`text-sm font-semibold transition-colors ${step === 'home' ? 'text-brand underline' : 'text-slate-600 hover:text-brand'}`}
            >
              Home
            </button>

            <button 
              onClick={() => setStep('pricing')}
              id="top_nav_pricing"
              className={`text-sm font-semibold transition-colors ${step === 'pricing' ? 'text-brand underline' : 'text-slate-600 hover:text-brand'}`}
            >
              Pricing
            </button>

            <button 
              onClick={() => { resetApp(); setStep('input'); }}
              id="top_nav_new"
              className="bg-brand hover:bg-brand-light text-white text-xs font-bold px-4.5 py-2.5 rounded-full transition-all shadow-xs"
            >
              {isPro ? "Analyze Unlimited" : "Analyze Free"}
            </button>
          </nav>
        </div>
      </header>

      {/* SNEAK PEEK FOR USER ADMIN PRACTICE PORTAL */}
      <AnimatePresence>
        {showAdminTab && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-gradient-to-r from-brand to-[#0d3c73] text-xs text-blue-100 py-3.5 px-6 border-b border-brand-dark/30 print:hidden"
            id="admin_submission_panel"
          >
            <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
              <div className="flex items-center gap-2">
                <span className="bg-white text-brand font-bold px-2 py-0.5 rounded text-[10px] tracking-wide uppercase">Admin Portal</span>
                <p className="font-semibold">Patient leads captured for licensing dentists (Active Inquiry Logs):</p>
              </div>
              <div className="flex flex-wrap gap-2 text-[11px]">
                {leads.map((lead, i) => (
                  <span key={lead.id || i} className="bg-brand-dark/40 border border-white/10 px-2 py-1 rounded flex items-center gap-1.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-sky-300"></span>
                    <span className="font-mono text-white font-medium">{lead.email}</span> 
                    <span className="text-slate-300">(${lead.estCost})</span>
                  </span>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MAIN CONTENT AREA */}
      <main className="flex-grow w-full max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-12 flex flex-col justify-center">
        
        {/* PAGE 1: HOME PAGE */}
        {step === 'home' && (
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-12 items-center"
            id="page_home"
          >
            {/* HERO TEXT */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 bg-blue-50 text-brand px-3.5 py-1.5 rounded-full text-xs font-semibold tracking-wide shadow-xs border border-blue-100">
                <Sparkles className="h-3.5 w-3.5 text-sky-600 animate-pulse" />
                <span>Powered by Gemini 3.5 — Personalized Dental Consumer Advocate</span>
              </div>
              
              <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-black text-[#002B5B] tracking-tight leading-none">
                Understand Your <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand to-sky-600">
                  Dental Treatment Plan
                </span> <br />
                Before You Sign.
              </h1>
              
              <p className="text-slate-600 text-base md:text-lg leading-relaxed max-w-xl">
                Get a plain-language explanation of every procedure, cost, and insurance coverage — powered by AI. Translate complex codes and evaluate average prices in seconds.
              </p>

              <div className="pt-4 flex flex-col sm:flex-row gap-4">
                <button
                  type="button"
                  id="btn_get_started"
                  onClick={() => setStep('input')}
                  className="bg-brand text-white font-display font-bold text-lg px-8 py-4.5 rounded-full hover:bg-brand-light transition-all flex items-center justify-center gap-3 shadow-lg hover:shadow-xl active:scale-[0.98] cursor-pointer"
                >
                  <span>Analyze My Treatment Plan — Free</span>
                  <ChevronRight className="h-5 w-5 text-white" />
                </button>
              </div>

              <div className="pt-6 grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-slate-200">
                <div className="flex gap-2.5 items-start">
                  <CheckCircle className="h-5 w-5 text-brand shrink-0 mt-0.5" />
                  <div>
                    <h5 className="font-semibold text-[#002B5B] text-sm">Decode Codes</h5>
                    <p className="text-xs text-slate-500 my-0.5">Explains standard American Dental Association codes instantly.</p>
                  </div>
                </div>
                <div className="flex gap-2.5 items-start">
                  <CheckCircle className="h-5 w-5 text-brand shrink-0 mt-0.5" />
                  <div>
                    <h5 className="font-semibold text-[#002B5B] text-sm">Cost Auditing</h5>
                    <p className="text-xs text-slate-500 my-0.5">Flags overpriced estimates compared to geographic averages.</p>
                  </div>
                </div>
                <div className="flex gap-2.5 items-start">
                  <CheckCircle className="h-5 w-5 text-brand shrink-0 mt-0.5" />
                  <div>
                    <h5 className="font-semibold text-[#002B5B] text-sm">Patient First</h5>
                    <p className="text-xs text-slate-500 my-0.5">Unbiased non-clinical advocacy so you avoid unnecessary work.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* DECORATIVE SUMMARY ACCENT BOX */}
            <div className="lg:col-span-5">
              <div className="bg-gradient-to-br from-brand to-[#04336c] p-6 md:p-8 rounded-3xl text-white shadow-2xl border border-brand-dark/20 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/10 rounded-full blur-3xl"></div>
                <div className="absolute -bottom-10 -left-10 w-44 h-44 bg-cyan-500/10 rounded-full blur-2xl"></div>
                
                <div className="relative space-y-6">
                  <div className="flex justify-between items-center border-b border-brand-light/40 pb-4">
                    <div className="flex items-center gap-2">
                      <div className="bg-white/15 p-2 rounded-lg">
                        <Activity className="h-4.5 w-4.5 text-sky-300" />
                      </div>
                      <span className="text-xs tracking-wider uppercase font-semibold text-slate-200 font-mono">Sample Patient Analysis</span>
                    </div>
                    <span className="text-[11px] font-mono bg-emerald-500/15 text-emerald-300 px-2.5 py-0.5 rounded border border-emerald-500/20 font-bold">Analysis Complete</span>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-white/10 p-4 rounded-xl border border-white/10 space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="font-bold text-slate-50">Procedure D4341 (Scaling)</span>
                        <span className="font-mono text-sky-200 font-semibold">$330.00</span>
                      </div>
                      <p className="text-[11px] text-slate-200 leading-relaxed">
                        <span className="font-semibold text-sky-300">Plain Translation:</span> Deep cleaning that reaches below the gumline to treat early gum disease and restore pristine gum state.
                      </p>
                      <p className="text-[10px] bg-brand-dark/60 p-2 rounded text-slate-300 font-mono italic">
                        💡 Suggestion: Standard coverage level is typically 80% with simple PPO plans.
                      </p>
                    </div>

                    <div className="bg-white/5 p-4 rounded-xl border border-white/5 space-y-2">
                      <div className="flex justify-between text-xs text-slate-300">
                        <span>Procedure D0150 (Evaluation)</span>
                        <span className="font-mono text-slate-200">$125.00</span>
                      </div>
                      <p className="text-[11px] text-slate-300">New patient comprehensive dental state observation.</p>
                    </div>
                  </div>

                  <div className="bg-brand-dark/40 p-4 rounded-xl border border-white/5 flex items-start gap-3">
                    <div className="bg-white/10 p-1.5 rounded-lg text-sky-300">
                      <Lock className="h-4 w-4" />
                    </div>
                    <div className="space-y-0.5">
                      <h6 className="text-[10px] font-bold text-slate-200 uppercase tracking-widest font-mono">Patient Agency Protections</h6>
                      <p className="text-[11px] text-slate-300 leading-normal">ClearPlan is private. We do not transmit records or logs to insurance firms.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* PAGE 2: PROCEDURES AND COST ENTRY INPUT PAGE */}
        {step === 'input' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="max-w-4xl mx-auto w-full"
            id="page_input"
          >
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden">
              
              {/* TOP HEADER */}
              <div className="bg-brand text-white p-6 md:p-8 space-y-2">
                <h2 className="font-display text-2xl md:text-3xl font-semibold tracking-tight">Enter Your Treatment Plan</h2>
                <p className="text-blue-100 text-sm">
                  Add the scheduled treatments manually, or copy/paste the patient invoice text directly:
                </p>
              </div>

              {/* QUICK FILL SAMPLES CONTAINER */}
              <div className="bg-slate-50 border-b border-slate-200 px-6 py-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                <div className="flex items-center gap-1.5 text-xs text-brand font-semibold uppercase tracking-wider font-mono">
                  <Sparkles className="h-4 w-4 text-sky-600 animate-pulse" />
                  <span>Interactive Testing Demos</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {SAMPLES.map((sample, i) => (
                    <button
                      key={i}
                      type="button"
                      id={`sample_btn_${i}`}
                      onClick={() => loadSample(i)}
                      className="text-xs bg-white text-slate-800 font-medium px-3 py-1.5 rounded-lg border border-slate-300 hover:bg-sky-50 hover:border-sky-300 hover:text-sky-950 transition-all cursor-pointer shadow-xs active:translate-y-px"
                    >
                      🧪 {sample.title}
                    </button>
                  ))}
                </div>
              </div>

              {/* TABS SELECTOR */}
              <div className="px-6 md:px-8 pt-6">
                <div className="flex border-b border-slate-200 gap-6">
                  <button
                    type="button"
                    onClick={() => setInputType('manual')}
                    id="tab_manual"
                    className={`pb-3 text-sm font-bold transition-all relative ${
                      inputType === 'manual' 
                        ? 'text-brand border-b-2 border-brand' 
                        : 'text-slate-400 hover:text-slate-700'
                    }`}
                  >
                    📝 Manual Procedure Rows
                  </button>
                  <button
                    type="button"
                    onClick={() => setInputType('pasted')}
                    id="tab_pasted"
                    className={`pb-3 text-sm font-bold transition-all relative ${
                      inputType === 'pasted' 
                        ? 'text-brand border-b-2 border-brand' 
                        : 'text-slate-400 hover:text-slate-700'
                    }`}
                  >
                    📋 Paste Full Proposal Text
                  </button>
                </div>
              </div>

              {/* FORM PAYLOAD PANEL */}
              <form onSubmit={handleProceedToEmail} className="p-6 md:p-8 space-y-6">
                
                {error && (
                  <div className="bg-rose-50 border border-rose-200 text-rose-800 text-sm px-4 py-3 rounded-xl flex items-start gap-2.5">
                    <AlertTriangle className="h-5 w-5 shrink-0 text-rose-600 mt-0.5" />
                    <div>
                      <p className="font-bold">Input Error</p>
                      <p className="text-xs text-rose-700">{error}</p>
                    </div>
                  </div>
                )}

                {/* MANUAL MODE */}
                {inputType === 'manual' && (
                  <div className="space-y-4">
                    <div className="flex justify-between items-center bg-slate-50 p-2 rounded-lg border border-slate-200/60">
                      <span className="text-xs font-mono tracking-wider font-semibold uppercase text-slate-500 pl-2">Scheduled Treatments</span>
                      <button
                        type="button"
                        onClick={addProcedureRow}
                        id="add_row_btn"
                        className="text-xs bg-brand text-white font-bold px-3 py-1.5 rounded-lg hover:bg-brand-light transition-colors flex items-center gap-1 active:scale-[0.98] cursor-pointer"
                      >
                        <Plus className="h-3.5 w-3.5" />
                        <span>Add Row</span>
                      </button>
                    </div>

                    <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
                      {manualProcedures.map((proc, idx) => (
                        <div key={idx} className="flex gap-3 items-center">
                          {/* INDEX BADGE */}
                          <span className="font-mono text-xs text-slate-400 bg-slate-100 h-9 w-9 flex items-center justify-center rounded-lg border border-slate-200 shrink-0 font-bold">
                            {idx + 1}
                          </span>
                          
                          {/* PROCEDURE INPUT */}
                          <div className="flex-grow">
                            <input
                              type="text"
                              value={proc.name}
                              onChange={(e) => handleManualProcedureChange(idx, 'name', e.target.value)}
                              placeholder="Procedure Name or Code (e.g. D2740 crown tooth 30)"
                              className="w-full text-sm bg-slate-50 border border-slate-300 focus:border-brand rounded-lg px-4.5 py-2.5 outline-hidden transition-all placeholder:text-slate-400"
                              required
                            />
                          </div>

                          {/* COST INPUT */}
                          <div className="w-[124px] md:w-[154px] relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <span className="text-slate-400 text-sm">$</span>
                            </div>
                            <input
                              type="number"
                              min="0"
                              step="any"
                              value={proc.cost}
                              onChange={(e) => handleManualProcedureChange(idx, 'cost', e.target.value)}
                              placeholder="Cost quoted"
                              className="w-full text-sm font-mono pl-7 pr-3 py-2.5 bg-slate-50 border border-slate-300 focus:border-brand rounded-lg outline-hidden transition-all placeholder:text-slate-400"
                            />
                          </div>

                          {/* DELETE ROW */}
                          <button
                            type="button"
                            onClick={() => removeProcedureRow(idx)}
                            className="bg-rose-50 hover:bg-rose-100 text-rose-700 p-2.5 rounded-lg border border-rose-200/50 hover:border-rose-300 transition-colors cursor-pointer"
                            title="Remove procedure"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>

                    {/* SUM TOTAL INDICATOR */}
                    <div className="bg-brand text-slate-100 p-4 rounded-xl flex justify-between items-center font-display border border-brand-dark/30">
                      <div>
                        <p className="text-xs uppercase tracking-wider text-blue-200 font-mono font-semibold">Patient Cost Subtotal</p>
                        <p className="text-[10px] text-blue-100/80">Before AI local market average adjustment & insurance benefits optimizations</p>
                      </div>
                      <div className="text-2xl font-mono font-bold text-sky-300">
                        ${getManualTotal().toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                    </div>
                  </div>
                )}

                {/* PASTED RAW INVOICE TEXT AREA */}
                {inputType === 'pasted' && (
                  <div className="space-y-3">
                    <label className="block text-sm font-bold text-slate-800" htmlFor="raw_text_plan">
                      Copy / Paste Dental Plan text:
                    </label>
                    <textarea
                      id="raw_text_plan"
                      value={rawText}
                      onChange={(e) => setRawText(e.target.value)}
                      placeholder="Paste your treatment proposal plan here. Try to capture treatment codes (DXXXX), item descriptions, molar numbers, prices and estimates..."
                      className="w-full h-[240px] text-sm font-mono bg-slate-50 border border-slate-300 focus:border-brand rounded-xl p-4.5 outline-hidden transition-all placeholder:text-slate-400 leading-relaxed resize-none"
                    ></textarea>
                    <p className="text-xs text-slate-500 leading-normal">
                      💡 Tip: Copying the text directly from a patient portal email, PDF printout, or dental care estimate works brilliantly. Our AI is tailored to extract codes and prices dynamically.
                    </p>
                  </div>
                )}

                {/* PROCEED TO EMAIL CAPTURE ACTION */}
                <div className="pt-4 border-t border-slate-100 flex justify-between items-center">
                  <button
                    type="button"
                    onClick={() => setStep('home')}
                    className="text-slate-600 hover:text-slate-950 font-semibold text-sm flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <ArrowLeft className="h-4 w-4" />
                    <span>Back to Home</span>
                  </button>

                  <button
                    type="submit"
                    id="btn_submit_plan"
                    className="bg-brand text-white font-bold text-sm px-7 py-3 rounded-full hover:bg-brand-light transition-all flex items-center gap-1.5 active:scale-[0.98] shadow-xs cursor-pointer"
                  >
                    <span>Proceed to Verification</span>
                    <ChevronRight className="h-4 w-4 text-white" />
                  </button>
                </div>

              </form>
            </div>
          </motion.div>
        )}

        {/* PAGE 3: EMAIL CAPTURE SCREEN */}
        {step === 'email-capture' && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-md mx-auto w-full"
            id="page_email_capture"
          >
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden relative">
              <div className="absolute top-0 left-0 w-full h-1.5 bg-brand"></div>

              <div className="p-6 md:p-8 space-y-6">
                
                {/* HEADLINE */}
                <div className="text-center space-y-3">
                  <div className="bg-blue-50 h-12 w-12 rounded-full flex items-center justify-center mx-auto text-brand border border-blue-100">
                    <Mail className="h-6 w-6" />
                  </div>
                  <h3 className="font-display text-2xl font-bold text-brand tracking-tight">Activate Patient Review</h3>
                  <p className="text-slate-500 text-xs leading-relaxed max-w-xs mx-auto">
                    Where should we register your plain-language dental report? Enter your email address below to view your results.
                  </p>
                </div>

                {error && (
                  <div className="bg-rose-50 border border-rose-200 text-rose-800 text-xs p-3 rounded-lg flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 shrink-0 text-rose-600" />
                    <p>{error}</p>
                  </div>
                )}

                {/* CAPTURE FORM */}
                <form onSubmit={handleAnalyzePlan} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 block" htmlFor="email_capture_input">
                      Dentist Advocacy Email Address:
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                        <Mail className="h-4 w-4" />
                      </div>
                      <input
                        type="email"
                        id="email_capture_input"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="you@example.com"
                        className="w-full pl-9.5 pr-4 py-3 bg-slate-50 border border-slate-300 focus:border-brand rounded-lg text-sm transition-all shadow-xs"
                      />
                    </div>
                  </div>

                  {/* CHECKBOX DISCLAIMER ACCEPTANCE */}
                  <div className="flex gap-3 bg-slate-50 p-3 rounded-lg border border-slate-200/50">
                    <input
                      type="checkbox"
                      id="opt_in_disclaimer"
                      className="mt-0.5 h-4 w-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500 focus:ring-offset-0 cursor-pointer"
                      checked={agreedToTerms}
                      onChange={(e) => setAgreedToTerms(e.target.checked)}
                    />
                    <label htmlFor="opt_in_disclaimer" className="text-[11px] text-slate-500 leading-normal cursor-pointer select-none">
                      I understand that ClearPlan is an automated educational platform providing AI-generated insights. <strong>It does not provide professional medical/dental diagnosis or advice.</strong>
                    </label>
                  </div>

                  {/* ACTION SUBMIT BUTTON */}
                  <button
                    type="submit"
                    id="btn_get_analysis"
                    disabled={loading}
                    className="w-full bg-brand text-white font-bold py-3.5 rounded-full hover:bg-brand-light transition-all flex items-center justify-center gap-2 text-sm shadow-md active:scale-[0.98] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <>
                        <RefreshCw className="h-4 w-4 animate-spin text-white" />
                        <span>Compiling Clinical AI Analysis...</span>
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4 text-white" />
                        <span>View Free AI Treatment Analysis &rarr;</span>
                      </>
                    )}
                  </button>
                </form>

                {/* BOTTOM BRAND GARANTUEE */}
                <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row justify-center items-center gap-4 sm:gap-6 text-[10px] text-slate-400 font-mono text-center">
                  <div className="flex items-center gap-1">
                    <Lock className="h-3 w-3 text-emerald-600 shrink-0" />
                    <span>Insurers Shielded</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <CheckCircle className="h-3 w-3 text-emerald-600 shrink-0" />
                    <span>Your data is never sold or shared with insurers or dental practices.</span>
                  </div>
                </div>

                {/* CANCEL ACCORD */}
                <div className="text-center pt-1">
                  <button 
                    type="button" 
                    onClick={() => setStep('input')}
                    id="back_to_edit"
                    className="text-xs text-slate-600 hover:text-brand font-bold underline transition-all cursor-pointer"
                  >
                    Cancel, go back and edit treatment plan rows
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* LOADING PROGRESS COMPONENT WHILE CALLING AI */}
        {loading && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-4 print:hidden"
            id="loading_overlay"
          >
            <div className="bg-brand text-white p-6 md:p-8 rounded-2xl border border-brand-dark/30 shadow-2xl max-w-sm w-full text-center space-y-6">
              <div className="inline-flex relative">
                <div className="h-16 w-16 rounded-full border-4 border-sky-400/20 border-t-sky-300 animate-spin"></div>
                <div className="absolute inset-2 bg-brand rounded-full flex items-center justify-center text-sky-300">
                  <Activity className="h-6 w-6 animate-pulse" />
                </div>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-display font-semibold text-lg text-white">Transcribing Dental Plan</h4>
                <p className="text-xs text-blue-100/80 leading-normal">
                  Our advocate dental AI is parsing standard insurance ADA codes, checking regional average treatment costs, and translating complex terms into patient-first terminology...
                </p>
              </div>

              <div className="bg-brand-dark/40 p-3 rounded-lg text-[10px] text-blue-200 font-mono text-left space-y-1 divide-y divide-brand-light/30">
                <div className="pb-1.5 flex justify-between">
                  <span>Contacting Gemini 3.5...</span>
                  <span className="text-sky-300">CONNECTING...</span>
                </div>
                <div className="py-1.5 flex justify-between">
                  <span>Translating dental jargon...</span>
                  <span className="text-sky-300">DECODING...</span>
                </div>
                <div className="pt-1.5 flex justify-between">
                  <span>Validating insurance thresholds...</span>
                  <span className="text-sky-300 font-bold">READY</span>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* PAGE 4: DETAILED AI RESULTS INTERFACE */}
        {step === 'results' && result && (
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
            id="page_results"
          >
            
            {/* ACTION BANNER ROW */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-200 pb-4 print:hidden">
              <div className="space-y-1">
                <button
                  onClick={() => setStep('input')}
                  id="results_nav_back"
                  className="text-xs text-slate-600 hover:text-brand font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <ArrowLeft className="h-3.5 w-3.5 text-sky-650" />
                  <span>Modify Dental Description Input</span>
                </button>
                <div className="flex items-center gap-2">
                  <span className="bg-brand text-slate-100 font-mono font-bold text-xs px-2.5 py-1 rounded">ClearPlan Report</span>
                  <h2 className="font-display text-2xl font-black text-[#002B5B] tracking-tight">Your AI Dental Plan Breakdown</h2>
                </div>
              </div>

              <div className="flex flex-wrap gap-2.5">
                <button
                  type="button"
                  onClick={() => window.print()}
                  id="print_btn"
                  className="bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold px-4.5 py-2.5 rounded-full transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="h-4 w-4" />
                  <span>Print Report (PDF)</span>
                </button>

                <button
                  type="button"
                  onClick={resetApp}
                  id="new_analysis_btn"
                  className="bg-brand hover:bg-brand-light text-white text-xs font-bold px-4.5 py-2.5 rounded-full transition-all flex items-center gap-1.5 shadow-xs active:translate-y-px cursor-pointer"
                >
                  <RefreshCw className="h-4 w-4" />
                  <span>New Analysis</span>
                </button>
              </div>
            </div>

            {/* AI OVERVIEW & EXECUTIVE ANALYTICAL DASHBOARD CARD */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 leading-relaxed">
              
              {/* PRIMARY INSIGHT SUMMARY */}
              <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
                <div className="flex items-center gap-2">
                  <div className="bg-blue-50 text-brand p-1.5 rounded-lg">
                    <Activity className="h-4 w-4" />
                  </div>
                  <h3 className="font-display font-semibold text-lg text-[#002B5B]">Patient-First General Assessment</h3>
                </div>
                
                <p className="text-slate-700 text-sm md:text-base leading-relaxed bg-slate-50/50 p-4 rounded-xl border border-slate-100">
                  {result.overallAnalysis.summary}
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  {/* PRIORITIZATION */}
                  <div className="space-y-1.5">
                    <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest font-mono">🚨 Action Care Prioritization</h4>
                    <p className="text-xs text-slate-600 bg-slate-50 p-3.5 rounded-lg border border-slate-200/50">
                      {result.overallAnalysis.prioritySection}
                    </p>
                  </div>

                  {/* SAVINGS OPPORTUNITY */}
                  <div className="space-y-1.5">
                    <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest font-mono">💡 Cost Savings / Staging Optimization</h4>
                    <p className="text-xs text-slate-600 bg-slate-50 p-3.5 rounded-lg border border-slate-200/50">
                      {result.overallAnalysis.insuranceAdvancementTips}
                    </p>
                  </div>
                </div>
              </div>

              {/* SAVINGS COMPACT SCORECARD */}
              <div className="lg:col-span-4 bg-gradient-to-br from-brand to-[#04336c] text-white rounded-2xl border border-brand-dark/20 p-6 flex flex-col justify-between relative overflow-hidden shadow-md">
                <div className="absolute top-0 right-0 w-24 h-24 bg-sky-500/10 rounded-full blur-2xl"></div>
                
                <div className="space-y-4 relative">
                  <div className="flex justify-between items-center border-b border-brand-light/30 pb-3">
                    <span className="text-[10px] uppercase font-mono text-slate-200 font-bold tracking-wider">Potential Savings Opportunity</span>
                    <span className="text-[10px] font-mono text-emerald-300 flex items-center gap-1 bg-emerald-500/20 px-1.5 py-0.5 rounded font-bold">
                      <ShieldCheck className="h-3 w-3" /> Enabled
                    </span>
                  </div>

                  <div className="space-y-1">
                    <span className="text-slate-200 text-xs block">Estimated Audit Savings Potential:</span>
                    <div className="flex items-baseline gap-1 text-sky-300 font-mono">
                      <span className="text-3xl md:text-4xl font-extrabold">{result.overallAnalysis.estimatedSavingsPotential}</span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-normal">
                      Potential discount computed from regional PPO networks, deductible staggering, and direct dentist contract negotiations formulas.
                    </p>
                  </div>
                </div>

                <div className="bg-brand-dark/50 p-3.5 rounded-xl border border-white/5 mt-6 space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-300">
                    <span>Audit Registry Code:</span>
                    <span className="text-slate-200 font-semibold">#CP-{(Math.floor(Math.random() * 89999) + 10000)}</span>
                  </div>
                  <div className="flex justify-between text-xs font-mono text-slate-300">
                    <span>Inquiry Registered:</span>
                    <span className="text-slate-200 font-semibold">{email}</span>
                  </div>
                </div>
              </div>

            </div>

            {/* MANDATORY THE TABLE OF DETAILED AI PROCEDURE PROCEDURES */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden" id="clearplan_results_table">
              
              <div className="bg-brand text-white p-5 md:p-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-sky-300" />
                  <h3 className="font-display font-semibold text-base md:text-lg text-white">Detailed Procedure-by-Procedure Clean Translation</h3>
                </div>
                <span className="text-xs font-mono text-blue-200">Total Analyzed Care Rows: {result.procedures.length}</span>
              </div>

              {/* TABLE ELEMENT */}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse table-auto">
                  <thead>
                    <tr className="bg-slate-50 text-slate-500 border-b border-slate-200 text-[11px] uppercase tracking-widest font-mono font-bold">
                      <th className="py-4.5 px-4 md:px-5 min-w-[180px]">Procedure</th>
                      <th className="py-4.5 px-4 md:px-5 min-w-[240px]">Plain Language Explanation</th>
                      <th className="py-4.5 px-4 md:px-5 min-w-[150px]">Typical Cost & Advice</th>
                      <th className="py-4.5 px-4 md:px-5 min-w-[160px]">Insurance Coverage</th>
                      <th className="py-4.5 px-4 md:px-5 min-w-[180px]">Recommendation Variance</th>
                      <th className="py-4.5 px-4 md:px-5 min-w-[200px] text-brand font-bold bg-blue-50/30">Question to Ask Your Dentist</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 text-slate-700 text-xs md:text-sm">
                    {result.procedures.map((proc, index) => (
                      <tr 
                        key={index} 
                        className="align-top hover:bg-slate-50/50 transition-colors"
                      >
                        {/* 1. PROCEDURE */}
                        <td className="py-5 px-4 md:px-5 font-bold text-brand text-xs md:text-[13px]">
                          <div className="flex items-start gap-1.5">
                            <span className="bg-blue-50 border border-blue-100 text-brand font-mono text-[10px] px-1.5 py-0.5 rounded font-bold shrink-0 mt-0.5">
                              {index + 1}
                            </span>
                            <span className="font-display text-[#002B5B] font-bold">{proc.procedure}</span>
                          </div>
                        </td>

                        {/* 2. PLAIN EXPLANATION */}
                        <td className="py-5 px-4 md:px-5 text-slate-600 text-xs md:text-[13px] leading-relaxed max-w-sm">
                          {proc.plainExplanation}
                        </td>

                        {/* 3. TYPICAL COST */}
                        <td className="py-5 px-4 md:px-5 max-w-[200px]">
                          <div className="space-y-1.5">
                            <span className="font-mono bg-blue-50 text-brand border border-blue-100 px-2 font-semibold py-0.5 rounded text-[11px] font-bold">
                              {proc.typicalCostRange}
                            </span>
                            <p className="text-[11.5px] text-slate-500 leading-relaxed font-mono">
                              {proc.costComparisonNotes}
                            </p>
                          </div>
                        </td>

                        {/* 4. INSURANCE COVERAGE */}
                        <td className="py-5 px-4 md:px-5 text-slate-600 text-xs md:text-[13px] max-w-[180px] leading-relaxed">
                          {proc.insuranceCoverageTypical}
                        </td>

                        {/* 5. RECOMMENDATION VARIANCE */}
                        <td className="py-5 px-4 md:px-5 text-slate-600 text-[12.5px] max-w-[200px] leading-relaxed">
                          {proc.recommendationVarianceReason}
                        </td>

                        {/* 6. QUESTION TO ASK */}
                        <td className="py-5 px-4 md:px-5 bg-blue-50/20 text-slate-900 border-l border-blue-100 font-medium text-xs md:text-[13px] max-w-[220px] leading-relaxed">
                          <p className="italic text-slate-800 bg-white border border-slate-200/60 p-2.5 rounded-lg text-xs font-semibold shadow-xs">
                            &quot;{proc.questionsToAsk}&quot;
                          </p>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* TABLE SUMMARY DECORATION */}
              <div className="bg-slate-50 border-t border-slate-200 p-4 text-center print:hidden">
                <p className="text-xs text-slate-500 font-semibold">
                  💡 Hint: Use the print button above to convert this breakdown into a PDF you can carry to your next cleaning or consultation appointment.
                </p>
              </div>

            </div>

            {/* MANDATORY THE DISCLAIMER BOX AT THE BOTTOM OF THE PAGE */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-5 md:p-6 text-xs text-amber-900 space-y-2 leading-relaxed" id="legal_disclaimer">
              <div className="flex items-center gap-2 font-bold text-amber-950 font-display text-sm">
                <AlertTriangle className="h-4.5 w-4.5 text-amber-700" />
                <span>Disclaimer & Important Patient Legal Confirmation</span>
              </div>
              <p>
                ClearPlan is an educational, AI-powered consumer advocate tool built for explanatory purposes only. ClearPlan is <strong>not</strong> a licensed medical provider, dental clinic, or insurance policy underwriter. The information, typical regional costs, and plain-language notes generated on this platform in no way constitute clinical dental advice, formal insurance coverage guarantees, diagnostic medical claims, or legally binding therapy recommendations.
              </p>
              <p>
                Dentistry requires in-person clinical examinations, visual tactile probing, periodontal probing, and x-ray diagnostics to prescribe therapies. Always consult with your primary licensed dentist, a qualified specialist, or obtain a professional second opinion before refusing treatment, postponing restorative dental services, or overriding professional clinical proposals. The user assumes all liability and risks for choices made based on platform insights.
              </p>
            </div>

            {/* ACTION FOOTER */}
            <div className="pt-4 flex justify-center items-center gap-4 print:hidden">
              <button
                type="button"
                onClick={() => setStep('input')}
                id="footer_edit_original"
                className="text-slate-600 hover:text-slate-900 text-xs font-semibold underline flex items-center gap-1 transition-all"
              >
                Go back & edit inputs
              </button>
              <span className="text-slate-300">|</span>
              <button
                type="button"
                onClick={resetApp}
                id="footer_start_fresh"
                className="text-slate-600 hover:text-slate-900 text-xs font-semibold underline flex items-center gap-1 transition-all"
              >
                Clear and start secondary plan analysis
              </button>
            </div>

          </motion.div>
        )}

        {/* PAGE 5: PRICING & TIERS PAGE */}
        {step === 'pricing' && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto space-y-10"
            id="pricing_page"
          >
            {/* INTRO HEADER */}
            <div className="text-center space-y-3">
              <h2 className="font-display text-3xl font-extrabold text-[#002B5B]">Flexible and Affordable Pricing</h2>
              <p className="text-slate-600 max-w-xl mx-auto text-sm md:text-base leading-relaxed">
                Choose the best tier to audit your restorative dental proposals, unlock plain-language translations, and detect insurance saving options.
              </p>
            </div>

            {/* UPGRADE SUMMARY ALERT BANNER */}
            {!isPro && freeAnalysesCount >= 1 && (
              <div className="bg-blue-50 border border-blue-200 text-brand p-4.5 rounded-xl flex items-center gap-3 text-sm font-medium">
                <AlertTriangle className="h-5 w-5 text-sky-600 shrink-0" />
                <p>
                  You have successfully completed your <strong>1 free analysis</strong>. To audit secondary files, paste diagnostic descriptions, or unlock persistent histories, upgrade to Pro below.
                </p>
              </div>
            )}

            {/* TWO PLAN BOXES */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
              
              {/* FREE TIER CARD */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 md:p-8 flex flex-col justify-between relative shadow-sm hover:shadow-md transition-all">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <span className="text-[10px] uppercase font-mono bg-slate-100 text-slate-600 px-2.5 py-1 rounded font-bold">Standard Tier</span>
                    <h3 className="font-display text-xl font-bold text-slate-900 mt-2">Free Plan</h3>
                    <p className="text-slate-500 text-xs">For single treatment plan checks.</p>
                  </div>

                  <div className="flex items-baseline gap-1 py-2 border-y border-slate-100">
                    <span className="text-4xl font-extrabold text-[#002B5B]">$0</span>
                    <span className="text-slate-500 text-xs font-medium">/ 1 Analysis total</span>
                  </div>

                  <ul className="space-y-3 text-xs text-slate-600">
                    <li className="flex items-center gap-2.5">
                      <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />
                      <span>1 standard dental treatment plan analysis</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />
                      <span>Procedure-by-procedure plain language logs</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />
                      <span>Estimated regional custom rate advice</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />
                      <span>Email capture required (no credit card)</span>
                    </li>
                  </ul>
                </div>

                <div className="pt-8">
                  {(!isPro && freeAnalysesCount >= 1) ? (
                    <button
                      disabled
                      className="w-full bg-slate-100 text-slate-450 font-bold py-3.5 px-4 rounded-xl text-xs cursor-not-allowed border border-slate-150"
                    >
                      Free Tier Used ({freeAnalysesCount}/1)
                    </button>
                  ) : isPro ? (
                    <button
                      onClick={() => setStep('input')}
                      className="w-full bg-slate-100 hover:bg-slate-200 text-brand font-bold py-3.5 px-4 rounded-xl text-xs transition-colors cursor-pointer"
                    >
                      Access Inputs
                    </button>
                  ) : (
                    <button
                      onClick={() => setStep('input')}
                      className="w-full bg-slate-100 hover:bg-slate-200 text-brand font-bold py-3.5 px-4 rounded-xl text-xs transition-colors cursor-pointer text-center"
                    >
                      Analyze Free Plan
                    </button>
                  )}
                </div>
              </div>

              {/* PRO TIER CARD */}
              <div className="bg-gradient-to-b from-white to-sky-50/20 rounded-2xl border-2 border-brand p-6 md:p-8 flex flex-col justify-between relative shadow-md hover:shadow-lg transition-all">
                <div className="absolute top-4 right-4 bg-brand text-white text-[9px] uppercase font-mono font-bold px-2.5 py-1 rounded-full tracking-wider shadow-xs">
                  ★ Recommended
                </div>

                <div className="space-y-6">
                  <div className="space-y-2">
                    <span className="text-[10px] uppercase font-mono bg-blue-100 text-brand px-2.5 py-1 rounded font-extrabold">Unlimited Access</span>
                    <h3 className="font-display text-xl font-bold text-brand mt-2">ClearPlan Pro</h3>
                    <p className="text-slate-500 text-xs">For family plans and unlimited analyses.</p>
                  </div>

                  <div className="flex items-baseline gap-1 py-2 border-y border-blue-100/60">
                    <span className="text-4xl font-extrabold text-brand">$12.99</span>
                    <span className="text-slate-500 text-xs font-semibold">/ month</span>
                  </div>

                  <ul className="space-y-3 text-xs text-slate-700 font-semibold">
                    <li className="flex items-center gap-2.5">
                      <Sparkles className="h-4 w-4 text-yellow-500 shrink-0 animate-pulse" />
                      <span><strong>Unlimited</strong> treatment plan analyses</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <Sparkles className="h-4 w-4 text-brand shrink-0" />
                      <span><strong>Save analysis history</strong> locally on device</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <Sparkles className="h-4 w-4 text-brand shrink-0" />
                      <span>Advanced dental coding recommendations</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <Sparkles className="h-4 w-4 text-brand shrink-0" />
                      <span>Premium priority server queues</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <Sparkles className="h-4 w-4 text-brand shrink-0" />
                      <span>Cancel immediately at any time</span>
                    </li>
                  </ul>
                </div>

                <div className="pt-8">
                  {isPro ? (
                    <div className="space-y-2">
                      <button
                        disabled
                        className="w-full bg-emerald-500 text-white font-bold py-3.5 px-4 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-sm"
                      >
                        <ShieldCheck className="h-4 w-4" />
                        <span>Pro Plan Active</span>
                      </button>
                      <button
                        onClick={() => {
                          setIsPro(false);
                          localStorage.setItem('clearplan_is_pro', 'false');
                        }}
                        className="w-full text-[10px] text-slate-400 hover:text-red-500 transition-colors py-1 hover:underline cursor-pointer"
                      >
                        Downgrade to test Free limits
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setShowCheckoutModal(true)}
                      className="w-full bg-gradient-to-r from-brand to-[#0a315e] hover:from-[#092d56] text-white font-bold py-3.5 px-4 rounded-xl text-xs transition-all shadow-md active:translate-y-px hover:shadow-lg cursor-pointer text-center"
                    >
                      Upgrade to Pro — $12.99/month
                    </button>
                  )}
                </div>
              </div>

            </div>

            {/* SAVED ANALYSIS HISTORY FOR PRO USERS */}
            {isPro && (
              <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-xs" id="pro_history_section">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-brand" />
                    <h3 className="font-display font-semibold text-base text-[#002B5B]">Your Saved Analysis History</h3>
                  </div>
                  <span className="text-xs bg-slate-100 font-mono px-2.5 py-1 rounded text-slate-605 font-bold">
                    {savedAnalyses.length} Saved {savedAnalyses.length === 1 ? 'Report' : 'Reports'}
                  </span>
                </div>

                {savedAnalyses.length === 0 ? (
                  <div className="text-center py-10 px-4 space-y-2">
                    <p className="text-slate-400 font-semibold text-xs">No saved analyses found on this device yet.</p>
                    <p className="text-slate-400 text-[11px]">Any plan analyses you generate as a Pro member will automatically appear here!</p>
                    <button
                      onClick={() => setStep('input')}
                      className="text-xs text-brand font-bold hover:underline"
                    >
                      Create Your First Analysis
                    </button>
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto pr-1">
                    {savedAnalyses.map((item) => (
                      <div 
                        key={item.id} 
                        onClick={() => loadSavedAnalysis(item)}
                        className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/50 cursor-pointer p-2 rounded-xl transition-all"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs text-slate-850 font-bold">{item.email}</span>
                            <span className="text-[10px] text-slate-400">
                              {new Date(item.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 leading-none">
                            Estimated Care Amount: <span className="font-semibold text-[#002B5B] font-mono">${item.estCost}</span>
                          </p>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={(e) => { e.stopPropagation(); loadSavedAnalysis(item); }}
                            className="bg-blue-50 text-brand px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-blue-100 transition-colors cursor-pointer"
                          >
                            Open Report
                          </button>
                          <button
                            onClick={(e) => deleteSavedAnalysis(item.id, e)}
                            className="bg-red-50 text-red-650 p-1.5 rounded-lg hover:bg-red-100 transition-colors cursor-pointer"
                            title="Delete Report"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* RETURN BUTTON */}
            <div className="text-center pt-2">
              <button
                onClick={() => setStep('home')}
                className="text-xs font-semibold text-slate-500 hover:text-brand underline cursor-pointer"
              >
                ← Back to Home
              </button>
            </div>

          </motion.div>
        )}

      </main>

      {/* SIMULATED STRIPE CHECKOUT MODAL */}
      <AnimatePresence>
        {showCheckoutModal && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 print:hidden" id="checkout_modal">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden"
            >
              {/* MODAL HEADER */}
              <div className="bg-[#5469d4] text-white p-5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="bg-white/10 p-1.5 rounded-lg">
                    <ShieldCheck className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-sm tracking-wide">Secure Stripe Checkout</h3>
                    <p className="text-[10px] text-blue-100 font-mono">Powered by Stripe Connect</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowCheckoutModal(false)}
                  className="text-white/80 hover:text-white font-bold text-lg select-none cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {/* MODAL BODY */}
              <form onSubmit={(e) => {
                e.preventDefault();
                setCheckoutProcessing(true);
                setTimeout(() => {
                  setCheckoutProcessing(false);
                  setIsPro(true);
                  localStorage.setItem('clearplan_is_pro', 'true');
                  setShowCheckoutModal(false);
                  setCheckoutCardName('');
                  setCheckoutCardNum('');
                  setCheckoutZip('');
                  setStep('pricing');
                }, 1500);
              }} className="p-6 space-y-4">
                <div className="text-center space-y-1">
                  <span className="text-[10px] bg-sky-50 text-brand font-bold font-mono px-2 py-0.5 rounded tracking-wide">Subscription Pack</span>
                  <h4 className="font-display font-extrabold text-brand text-lg">ClearPlan Pro Tier</h4>
                  <p className="text-slate-600 text-xs font-mono font-bold">$12.99 / Month</p>
                </div>

                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200/60 text-[10px] text-slate-500 leading-normal space-y-1">
                  <p className="font-bold flex items-center gap-1 text-slate-650">
                    <span>💡 Sandbox / Demonstration Mode Enabled</span>
                  </p>
                  <p>Secure subscription with simulated merchant validation. Enter any name and credit card attributes below to complete upgrade instantly.</p>
                </div>

                <div className="space-y-3.5 text-xs text-left">
                  {/* Name field */}
                  <div className="space-y-1.5">
                    <label className="block text-slate-500 font-bold tracking-wider uppercase text-[10px]">Cardholder Name</label>
                    <input 
                      type="text"
                      required
                      value={checkoutCardName}
                      onChange={(e) => setCheckoutCardName(e.target.value)}
                      placeholder="e.g. John Doe"
                      className="w-full bg-slate-50 p-3.5 rounded-xl border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#5469d4]/20 focus:border-[#5469d4] transition-all font-medium text-slate-800"
                    />
                  </div>

                  {/* Card number */}
                  <div className="space-y-1.5">
                    <label className="block text-slate-500 font-bold tracking-wider uppercase text-[10px]">Card Number</label>
                    <div className="relative">
                      <input 
                        type="text"
                        required
                        value={checkoutCardNum}
                        onChange={(e) => {
                          const val = e.target.value.replace(/[^0-9]/g, '');
                          setCheckoutCardNum(val.match(/.{1,4}/g)?.join(' ') || val);
                        }}
                        maxLength={19}
                        placeholder="4242 4242 4242 4242"
                        className="w-full bg-slate-50 p-3.5 pl-11 rounded-xl border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#5469d4]/20 focus:border-[#5469d4] transition-all font-semibold tracking-wider text-slate-800 font-mono"
                      />
                      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-[10px]">💳</span>
                    </div>
                  </div>

                  {/* Row expire and CVV and Zip */}
                  <div className="grid grid-cols-3 gap-3">
                    <div className="space-y-1">
                      <label className="block text-slate-500 font-bold tracking-wider uppercase text-[9px]">Expires</label>
                      <input 
                        type="text"
                        required
                        maxLength={5}
                        placeholder="MM/YY"
                        className="w-full bg-slate-50 p-3 rounded-xl border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#5469d4]/20 focus:border-[#5469d4] transition-all text-center tracking-wide font-mono font-bold text-slate-800"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="block text-slate-500 font-bold tracking-wider uppercase text-[9px]">CVC Code</label>
                      <input 
                        type="password"
                        required
                        maxLength={3}
                        placeholder="***"
                        className="w-full bg-slate-50 p-3 rounded-xl border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#5469d4]/20 focus:border-[#5469d4] transition-all text-center tracking-widest font-mono font-bold text-slate-800"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="block text-slate-500 font-bold tracking-wider uppercase text-[9px]">Zip Code</label>
                      <input 
                        type="text"
                        required
                        value={checkoutZip}
                        onChange={(e) => setCheckoutZip(e.target.value.replace(/[^0-9]/g, ''))}
                        maxLength={5}
                        placeholder="90210"
                        className="w-full bg-slate-50 p-3 rounded-xl border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#5469d4]/20 focus:border-[#5469d4] transition-all text-center font-mono font-bold text-slate-800"
                      />
                    </div>
                  </div>
                </div>

                {/* PLACEHOLDER SUBMIT BUTTON */}
                <div className="pt-4 space-y-2">
                  <button
                    type="submit"
                    disabled={checkoutProcessing}
                    className="w-full bg-[#5469d4] hover:bg-[#4353bc] text-white font-bold py-3.5 px-4 rounded-xl text-xs transition-all shadow-md active:translate-y-px flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {checkoutProcessing ? (
                      <span className="flex items-center gap-2">
                        <span className="animate-spin h-3.5 w-3.5 border-2 border-white border-t-transparent rounded-full"></span>
                        <span>Verifying Stripe Checkout...</span>
                      </span>
                    ) : (
                      <span>Upgrade to Pro — $12.99/month</span>
                    )}
                  </button>
                  <p className="text-[9px] text-center text-slate-400">
                    🔒 SSL Encrypted and Shielded. This demo integrates full state upgrades upon billing click.
                  </p>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* FOOTER */}
      <footer className="bg-slate-900 text-slate-400 py-8 px-6 text-xs text-center border-t border-slate-800 print:bg-white print:text-black print:border-t-2 print:border-slate-300">
        <div className="max-w-7xl mx-auto space-y-3">
          <p className="font-display font-bold text-slate-300 tracking-wider">
            ClearPlan Dental Platform &copy; {new Date().getFullYear()}
          </p>
          <p className="max-w-xl mx-auto leading-relaxed">
            Empowering patients with modern dental treatment insights, price transparency, and dental benefit hacks. Free of commercial bias.
          </p>
          <div className="flex justify-center items-center gap-3 text-slate-500 font-mono text-[10px] print:hidden">
            <span>© 2026 ClearPlan</span>
            <span>&bull;</span>
            <button 
              onClick={() => {
                setEmail('SwearingenDDS@gmail.com');
                setShowAdminTab(true);
              }}
              id="dd_admin_shortcut"
              className="hover:text-sky-400 underline cursor-pointer"
            >
              Demo Admin (DDS)
            </button>
          </div>
        </div>
      </footer>

    </div>
  );
}
