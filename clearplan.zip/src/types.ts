/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ManualProcedure {
  name: string;
  cost: string;
}

export interface AnalyzedProcedure {
  procedure: string;
  plainExplanation: string;
  typicalCostRange: string;
  costComparisonNotes: string;
  insuranceCoverageTypical: string;
  recommendationVarianceReason: string;
  questionsToAsk: string;
}

export interface OverallAnalysis {
  summary: string;
  prioritySection: string;
  insuranceAdvancementTips: string;
  estimatedSavingsPotential: string;
}

export interface CompilationResult {
  procedures: AnalyzedProcedure[];
  overallAnalysis: OverallAnalysis;
}

export type AppState = 'home' | 'input' | 'email-capture' | 'results' | 'pricing';
