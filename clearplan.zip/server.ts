import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

// Simple in-memory logger for captured leads/submissions
interface DentalSubmission {
  id: string;
  email: string;
  timestamp: string;
  itemCount: number;
  estCost: number;
}

const capturedSubmissions: DentalSubmission[] = [];

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Crucial parse middle-ware
  app.use(express.json());

  // Initialize Gemini Client with correct modern parameters
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  // Server-side analytical handler
  app.post("/api/analyze-treatment-plan", async (req, res) => {
    try {
      const { email, rawText, manualProcedures } = req.body;

      if (!email) {
        return res.status(400).json({ error: "Email is required to proceed with dental treatment analysis." });
      }

      let itemCount = 0;
      let estCost = 0;

      // Extract details for lead tracking logs
      if (manualProcedures && Array.isArray(manualProcedures)) {
        itemCount = manualProcedures.length;
        estCost = manualProcedures.reduce((acc, p) => acc + (parseFloat(p.cost) || 0), 0);
      } else if (rawText) {
        itemCount = 1;
        // Simple regex cost estimator
        const dollarMatches = rawText.match(/\$?([0-9]{3,5})/g);
        if (dollarMatches) {
          estCost = dollarMatches.reduce((acc: number, str: string) => acc + (parseFloat(str.replace(/[^0-9.]/g, '')) || 0), 0);
        }
      }

      // Store captured e-mail lead
      capturedSubmissions.push({
        id: Math.random().toString(36).substring(7),
        email: email.trim(),
        timestamp: new Date().toISOString(),
        itemCount,
        estCost
      });

      console.log(`[ClearPlan] Leads Captured: ${email} for treatment plan totaling $${estCost}`);

      // Compose input content for AI interpretation
      let treatmentPlanDetails = "";
      if (manualProcedures && Array.isArray(manualProcedures) && manualProcedures.length > 0) {
        treatmentPlanDetails = "MANUALLY ENTERED RESTORATIVE TREATMENTS:\n" + 
          manualProcedures.map((p, idx) => 
            `- Procedure ${idx + 1}: Name="${p.name}", Patient Out-of-pocket Cost Quoted="$${p.cost}"`
          ).join("\n");
      } else if (rawText) {
        treatmentPlanDetails = `PASTED RAW DENTAL INVOICE TEXT:\n${rawText}`;
      } else {
        return res.status(400).json({ error: "Please enter dental procedures or paste your dental invoice." });
      }

      // Setup Gemini AI prompt
      const prompt = `You are ClearPlan, a compassionate, plain-language dental advocate, veteran dental consultant, and dental insurance coder.
The following is a dental treatment plan and cost summary submitted by a patient.
Your mission is to explain these procedures in warm, accessible, plain language, audit the costs to tell them if they are getting a good deal, explain standard insurance rules, outline variances/alternative materials, and give them smart questions to ask their dentist to save money or get better outcomes.

Input Dental Care Details:
${treatmentPlanDetails}

You must respond with a JSON object that strictly adheres to the following structural schema definition:
{
  "procedures": [
    {
      "procedure": "Standard name & dental code if recognized (e.g. D2740 - Ceramic Crown or D4341 - Scaling & Root Planing)",
      "plainExplanation": "Clear, reassuring, human-understandable explanation of what the procedure is, what it does for their health, and why standard crowns or deep cleanings are recommended. Do not use scary descriptions.",
      "typicalCostRange": "Market customary rate range, e.g. $1,100 - $1,600",
      "costComparisonNotes": "Helpful notes advising on how their quoted price compares to market average (e.g. 'Your $950 quote is highly competitive and below 75% of domestic pricing').",
      "insuranceCoverageTypical": "Standard dental insurance PPO coverage percentage, what category it falls under (Preventive/Basic/Major), and if deductibles typically apply.",
      "recommendationVarianceReason": "Alternatives or questions regarding materials (e.g., Composite bond vs Crown, Porcelain vs Zirconia crown, implant vs bridge), and explanation of why this therapy was recommended over others.",
      "questionsToAsk": "One gentle, professional, yet precise dental audit question to ask the dentist to assert their health rights."
    }
  ],
  "overallAnalysis": {
    "summary": "Short, reassuring overview of the entire plan (e.g., 'Your plan focuses on deep gum care and restoring one molar. It is a solid plan but minor adjustments can save you money').",
    "prioritySection": "Actionable instructions on what is high priority (immediate treatment) vs elective/postponable work to stagger costs.",
    "insuranceAdvancementTips": "Tactical insurance hacks (e.g., 'Since your crown is major restorative care, ask to schedule it in January to stagger it across two separate deductible calendars' or 'Submit a Pre-Authorization first').",
    "estimatedSavingsPotential": "Estimated possible total outpatient savings if optimization hacks are used, e.g. '$350 - $700'"
  }
}

Generate clinical-grade, accurate dental answers. Always write reassuring, plain-language text that empowers patients without creating medical panic.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              procedures: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    procedure: { type: Type.STRING },
                    plainExplanation: { type: Type.STRING },
                    typicalCostRange: { type: Type.STRING },
                    costComparisonNotes: { type: Type.STRING },
                    insuranceCoverageTypical: { type: Type.STRING },
                    recommendationVarianceReason: { type: Type.STRING },
                    questionsToAsk: { type: Type.STRING }
                  },
                  required: [
                    "procedure",
                    "plainExplanation",
                    "typicalCostRange",
                    "costComparisonNotes",
                    "insuranceCoverageTypical",
                    "recommendationVarianceReason",
                    "questionsToAsk"
                  ]
                }
              },
              overallAnalysis: {
                type: Type.OBJECT,
                properties: {
                  summary: { type: Type.STRING },
                  prioritySection: { type: Type.STRING },
                  insuranceAdvancementTips: { type: Type.STRING },
                  estimatedSavingsPotential: { type: Type.STRING }
                },
                required: [
                  "summary",
                  "prioritySection",
                  "insuranceAdvancementTips",
                  "estimatedSavingsPotential"
                ]
              }
            },
            required: ["procedures", "overallAnalysis"]
          }
        }
      });

      const jsonString = response.text?.trim();
      if (!jsonString) {
        throw new Error("Empty representation generated by the underlying model.");
      }

      const payload = JSON.parse(jsonString);
      res.json(payload);

    } catch (err: any) {
      console.error("[ClearPlan API Error]", err);
      res.status(500).json({
        error: "Our dental AI analyst was unable to compile this structured output. Please edit your procedure inputs and try again.",
        details: err?.message || ""
      });
    }
  });

  // Lead dashboard analytics route for client verification
  app.get("/api/dashboard-leads", (req, res) => {
    res.json({ leads: capturedSubmissions });
  });

  // Vite Integration Setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[ClearPlan] Live and serving on port ${PORT}`);
  });
}

startServer();
